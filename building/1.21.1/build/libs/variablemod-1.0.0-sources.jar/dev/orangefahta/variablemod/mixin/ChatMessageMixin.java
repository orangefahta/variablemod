package dev.orangefahta.variablemod.mixin;

import dev.orangefahta.variablemod.VariableMod;
import dev.orangefahta.variablemod.command.CommandInterceptor;
import dev.orangefahta.variablemod.lang.Lang;
import net.minecraft.class_2797;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_9449;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Перехват чата и чат-команд
 * @author @OrangeFaHTA
 * @version 1.0.0
 */
@Mixin(value = class_3244.class, priority = 900)
public abstract class ChatMessageMixin {

    @Shadow
    public class_3222 player;

    @ModifyVariable(
        method = "executeCommand",
        at = @At("HEAD"),
        argsOnly = true,
        index = 1
    )
    private String varmod_resolveCommand(String command) {
        if (command == null || (!command.contains("v:") && !command.contains("v!:"))) return command;
        try {
            if (player != null) {
                String resolved = CommandInterceptor.resolveCommand(command, player.method_5671());
                if (!resolved.equals(command)) {
                    VariableMod.LOGGER.info(Lang.get("variablemod.log.exec_cmd_resolve"), command, resolved);
                }
                return resolved;
            }
        } catch (Exception e) {
            VariableMod.LOGGER.error(Lang.get("variablemod.log.exec_cmd_error"), e.toString());
        }
        return command;
    }

    @Inject(
        method = "onChatMessage",
        at = @At("HEAD"),
        cancellable = true
    )
    private void varmod_resolveChatPacket(class_2797 packet, CallbackInfo ci) {
        if (packet == null) return;
        String message = packet.comp_945();
        if (message == null || (!message.contains("v:") && !message.contains("v!:"))) return;

        try {
            if (player != null) {
                String resolved = CommandInterceptor.resolveCommand(message, player.method_5671());
                if (!resolved.equals(message)) {
                    VariableMod.LOGGER.info(Lang.get("variablemod.log.chat_intercept"), message, resolved);
                    ci.cancel();
                    
                    class_2797 newPacket = new class_2797(
                        resolved,
                        packet.comp_946(),
                        packet.comp_947(),
                        packet.comp_948(),
                        packet.comp_970()
                    );
                    ((class_3244)(Object)this).method_12048(newPacket);
                }
            }
        } catch (Exception e) {
            VariableMod.LOGGER.error(Lang.get("variablemod.log.chat_error"), e.toString());
        }
    }

    @ModifyVariable(
        method = "onChatCommandSigned",
        at = @At("HEAD"),
        argsOnly = true
    )
    private class_9449 varmod_resolveChatCommand(class_9449 packet) {
        if (packet == null) return packet;
        
        String command = packet.comp_2532();
        if (command == null || (!command.contains("v:") && !command.contains("v!:"))) return packet;

        try {
            if (player != null) {
                String resolved = CommandInterceptor.resolveCommand(command, player.method_5671());
                if (!resolved.equals(command)) {
                    VariableMod.LOGGER.info(Lang.get("variablemod.log.say_intercept"), command, resolved);
                    
                    return new class_9449(
                        resolved,
                        packet.comp_2533(),
                        packet.comp_2534(),
                        packet.comp_2535(), 
                        packet.comp_2536() 
                    );
                }
            }
        } catch (Exception e) {
            VariableMod.LOGGER.error(Lang.get("variablemod.log.say_error"), e.toString());
        }
        return packet;
    }
}