package dev.orangefahta.variablemod.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import dev.orangefahta.variablemod.VariableMod;
import dev.orangefahta.variablemod.lang.Lang;
import dev.orangefahta.variablemod.storage.BuiltinVariables;
import dev.orangefahta.variablemod.storage.VariableStorage;
import dev.orangefahta.variablemod.storage.VariableStorage.VarType;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

/**
 * Команды /variable
 * @author @OrangeFaHTA
 * @version 1.1.0
 */
public class VariableCommand {

    private static final SuggestionProvider<class_2168> VAR_NAMES =
        (ctx, builder) -> {
            VariableStorage.names().forEach(builder::suggest);
            return builder.buildFuture();
        };

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
            class_2170.method_9247("variable")
                .requires(src -> src.method_9259(2))

                .then(class_2170.method_9247("new")
                    .then(class_2170.method_9244("name", StringArgumentType.word())
                        .then(class_2170.method_9244("value", StringArgumentType.greedyString())
                            .executes(VariableCommand::cmdNew))))

                .then(class_2170.method_9247("delete")
                    .then(class_2170.method_9244("name", StringArgumentType.word())
                        .suggests(VAR_NAMES)
                        .executes(VariableCommand::cmdDelete)))

                .then(class_2170.method_9247("edit")
                    .then(class_2170.method_9244("name", StringArgumentType.word())
                        .suggests(VAR_NAMES)
                        .then(class_2170.method_9244("value", StringArgumentType.greedyString())
                            .executes(VariableCommand::cmdEdit))))

                .then(class_2170.method_9247("type")
                    .then(class_2170.method_9244("name", StringArgumentType.word())
                        .suggests(VAR_NAMES)
                        .then(class_2170.method_9247("text")
                            .executes(ctx -> cmdType(ctx, VarType.TEXT)))
                        .then(class_2170.method_9247("number")
                            .executes(ctx -> cmdType(ctx, VarType.NUMBER)))))

                .then(class_2170.method_9247("cfg")
                    .then(class_2170.method_9244("name", StringArgumentType.word())
                        .suggests(VAR_NAMES)
                        .executes(VariableCommand::cmdCfg)))

                .then(class_2170.method_9247("list")
                    .executes(VariableCommand::cmdList))

                .then(class_2170.method_9247("builtins")
                    .executes(VariableCommand::cmdBuiltins))
        );

        VariableMod.LOGGER.info(Lang.get("variablemod.log.cmd_registered"));
    }

    private static void sendLine(class_2168 src, class_5250 text) {
        src.method_9226(() -> text, false);
    }

    private static class_5250 t(String text, class_124... fmts) {
        class_5250 mt = class_2561.method_43470(text);
        for (class_124 f : fmts) mt = mt.method_27692(f);
        return mt;
    }

    private static int cmdNew(CommandContext<class_2168> ctx) {
        String name  = StringArgumentType.getString(ctx, "name");
        String value = StringArgumentType.getString(ctx, "value");
        VariableMod.LOGGER.info("[VariableMod] CMD new '{}' = '{}'", name, value);

        if (VariableStorage.create(name, value)) {
            sendLine(ctx.getSource(), t(Lang.fmt("variablemod.cmd.created", name, value), class_124.field_1060));
            return 1;
        } else {
            ctx.getSource().method_9213(t(Lang.fmt("variablemod.cmd.already_exists", name, name), class_124.field_1061));
            return 0;
        }
    }

    private static int cmdDelete(CommandContext<class_2168> ctx) {
        String name = StringArgumentType.getString(ctx, "name");
        VariableMod.LOGGER.info("[VariableMod] CMD delete '{}'", name);

        if (VariableStorage.delete(name)) {
            sendLine(ctx.getSource(), t(Lang.fmt("variablemod.cmd.deleted", name), class_124.field_1060));
            return 1;
        } else {
            ctx.getSource().method_9213(t(Lang.fmt("variablemod.cmd.not_found", name), class_124.field_1061));
            return 0;
        }
    }

    private static int cmdEdit(CommandContext<class_2168> ctx) {
        String name  = StringArgumentType.getString(ctx, "name");
        String value = StringArgumentType.getString(ctx, "value");
        VariableMod.LOGGER.info("[VariableMod] CMD edit '{}' = '{}'", name, value);

        if (!VariableStorage.exists(name)) {
            ctx.getSource().method_9213(t(Lang.fmt("variablemod.cmd.not_found", name), class_124.field_1061));
            return 0;
        }
        if (VariableStorage.edit(name, value)) {
            sendLine(ctx.getSource(), t(Lang.fmt("variablemod.cmd.edited", name, value), class_124.field_1060));
            return 1;
        } else {
            ctx.getSource().method_9213(t(Lang.fmt("variablemod.cmd.not_a_number", value, name), class_124.field_1061));
            return 0;
        }
    }

    private static int cmdType(CommandContext<class_2168> ctx, VarType newType) {
        String name = StringArgumentType.getString(ctx, "name");
        VariableMod.LOGGER.info("[VariableMod] CMD type '{}' -> {}", name, newType);

        int result = VariableStorage.setType(name, newType);
        switch (result) {
            case 0 -> sendLine(ctx.getSource(),
                t(Lang.fmt("variablemod.cmd.type_changed", name, newType.name().toLowerCase()), class_124.field_1060));
            case -1 -> ctx.getSource().method_9213(
                t(Lang.fmt("variablemod.cmd.not_found", name), class_124.field_1061));
            case -2 -> ctx.getSource().method_9213(
                t(Lang.fmt("variablemod.cmd.value_not_number", VariableStorage.get(name).value), class_124.field_1061));
        }
        return result == 0 ? 1 : 0;
    }

    private static int cmdCfg(CommandContext<class_2168> ctx) {
        String name = StringArgumentType.getString(ctx, "name");
        VariableStorage.Variable v = VariableStorage.get(name);

        if (v == null) {
            ctx.getSource().method_9213(t(Lang.fmt("variablemod.cmd.not_found", name), class_124.field_1061));
            return 0;
        }

        sendLine(ctx.getSource(), t(Lang.fmt("variablemod.cmd.cfg_header", name), class_124.field_1065));
        sendLine(ctx.getSource(), t(Lang.fmt("variablemod.cmd.cfg_value", v.value), class_124.field_1080));
        sendLine(ctx.getSource(), t(Lang.fmt("variablemod.cmd.cfg_type", v.type.name().toLowerCase()), class_124.field_1080));
        return 1;
    }

    private static int cmdList(CommandContext<class_2168> ctx) {
        if (VariableStorage.names().isEmpty()) {
            sendLine(ctx.getSource(), t(Lang.get("variablemod.cmd.list_empty"), class_124.field_1080));
            return 1;
        }
        sendLine(ctx.getSource(), t(Lang.get("variablemod.cmd.list_header"), class_124.field_1065));
        for (String name : VariableStorage.names()) {
            VariableStorage.Variable v = VariableStorage.get(name);
            sendLine(ctx.getSource(),
                t(Lang.fmt("variablemod.cmd.list_entry", name, v.value, v.type.name().toLowerCase()), class_124.field_1068));
        }
        return 1;
    }

    private static int cmdBuiltins(CommandContext<class_2168> ctx) {
        sendLine(ctx.getSource(), t(Lang.get("variablemod.cmd.builtins_header"), class_124.field_1065));
        BuiltinVariables.descriptions().forEach((name, desc) ->
            sendLine(ctx.getSource(),
                t("  v!:" + name, class_124.field_1054)
                    .method_10852(t(" — " + desc, class_124.field_1080))));
        return 1;
    }
}
