package dev.orangefahta.variablemod.mixin;

import dev.orangefahta.variablemod.VariableMod;
import dev.orangefahta.variablemod.command.CommandInterceptor;
import dev.orangefahta.variablemod.lang.Lang;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * Индекс команд.
 * @author @OrangeFaHTA
 * @version 1.1.0
 */
@Mixin(value = class_2170.class, priority = 900)
public abstract class VarCommandMixin {

    private static final ThreadLocal<class_2168> SOURCE_HOLDER = new ThreadLocal<>();

    @ModifyVariable(
        method = "executeWithPrefix",
        at = @At("HEAD"),
        argsOnly = true,
        index = 1
    )
    private class_2168 varmod_captureSource(class_2168 source) {
        VariableMod.LOGGER.info(Lang.get("variablemod.log.exec_prefix_src"),
            source != null ? source.method_9214() : "null");
        SOURCE_HOLDER.set(source);
        return source;
    }

    @ModifyVariable(
        method = "executeWithPrefix",
        at = @At("HEAD"),
        argsOnly = true,
        index = 2
    )
    private String varmod_resolveTokens(String command) {
        VariableMod.LOGGER.info(Lang.get("variablemod.log.exec_prefix_cmd"), command);

        if (!command.contains("v:") && !command.contains("v!:")) return command;

        class_2168 source = SOURCE_HOLDER.get();
        String resolved = CommandInterceptor.resolveCommand(command, source);

        if (!resolved.equals(command)) {
            VariableMod.LOGGER.info(Lang.get("variablemod.log.exec_prefix_res"), command, resolved);
        }
        return resolved;
    }
}
