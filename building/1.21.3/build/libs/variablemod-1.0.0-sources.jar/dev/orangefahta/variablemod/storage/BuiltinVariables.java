package dev.orangefahta.variablemod.storage;

import dev.orangefahta.variablemod.lang.Lang;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_1934;
import net.minecraft.class_2168;
import net.minecraft.class_3222;

/**
 * Встроенные переменные (v!:).
 *
 * @author @OrangeFaHTA
 * @version 1.1.0
 * Full list:
 *   v!:nickname   — display name of the player
 *   v!:name       — raw username (no formatting)
 *   v!:gamemode   — current gamemode (survival/creative/adventure/spectator)
 *   v!:world      — dimension key (e.g. minecraft:overworld)
 *   v!:x          — block X coordinate
 *   v!:y          — block Y coordinate
 *   v!:z          — block Z coordinate
 *   v!:health     — current health (integer)
 *   v!:food       — food level (integer)
 *   v!:xp         — total experience points
 *   v!:level      — experience level
 *   v!:time       — current in-game time (HH:mm)
 *   v!:date       — real-world date (yyyy-MM-dd)
 *   v!:day        — current in-game day number
 *   v!:onlinecnt  — number of players currently online
 */
public class BuiltinVariables {
    private static final String[] NAMES = {
        "nickname", "name", "gamemode", "world",
        "x", "y", "z",
        "health", "food", "xp", "level",
        "time", "date", "day", "onlinecnt"
    };

    public static Set<String> names() {
        java.util.LinkedHashSet<String> set = new java.util.LinkedHashSet<>();
        for (String n : NAMES) set.add(n);
        return set;
    }

    public static Map<String, String> descriptions() {
        Map<String, String> map = new LinkedHashMap<>();
        for (String name : NAMES) {
            map.put(name, Lang.get("variablemod.builtin." + name));
        }
        return map;
    }

    public static String resolve(String name, class_2168 source) {
        class_3222 player = null;
        try {
            player = source != null ? source.method_44023() : null;
        } catch (Exception ignored) {}

        return switch (name) {
            case "nickname" -> player != null
                ? player.method_5476().getString()
                : (source != null ? source.method_9214() : "?");

            case "name" -> player != null
                ? player.method_5477().getString()
                : (source != null ? source.method_9214() : "?");

            case "gamemode" -> player != null
                ? gamemodeString(player.field_13974.method_14257())
                : "unknown";

            case "world" -> source != null
                ? source.method_9225().method_27983().method_29177().toString()
                : "unknown";

            case "x" -> player != null
                ? String.valueOf(player.method_31477())
                : (source != null ? String.valueOf((int) source.method_9222().field_1352) : "0");

            case "y" -> player != null
                ? String.valueOf(player.method_31478())
                : (source != null ? String.valueOf((int) source.method_9222().field_1351) : "0");

            case "z" -> player != null
                ? String.valueOf(player.method_31479())
                : (source != null ? String.valueOf((int) source.method_9222().field_1350) : "0");

            case "health" -> player != null
                ? String.valueOf((int) player.method_6032())
                : "?";

            case "food" -> player != null
                ? String.valueOf(player.method_7344().method_7586())
                : "?";

            case "xp" -> player != null
                ? String.valueOf(player.field_7495)
                : "?";

            case "level" -> player != null
                ? String.valueOf(player.field_7520)
                : "?";

            case "time" -> {
                if (source != null) {
                    long ticks = source.method_9225().method_8532() % 24000;
                    int hours   = (int) ((ticks / 1000 + 6) % 24);
                    int minutes = (int) ((ticks % 1000) * 60 / 1000);
                    yield String.format("%02d:%02d", hours, minutes);
                }
                yield "00:00";
            }

            case "date" -> LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));

            case "day" -> source != null
                ? String.valueOf(source.method_9225().method_8510() / 24000)
                : "0";

            case "onlinecnt" -> source != null
                ? String.valueOf(source.method_9211().method_3788())
                : "0";

            default -> null;
        };
    }

    private static String gamemodeString(class_1934 mode) {
        return switch (mode) {
            case field_9215  -> "survival";
            case field_9220  -> "creative";
            case field_9216 -> "adventure";
            case field_9219 -> "spectator";
        };
    }
}
